Game Development - Assignment 1

https://github.com/Gerard346/Game-Dev2019

W/A/S/D -> Controls for moving the player

SPACE -> Jump