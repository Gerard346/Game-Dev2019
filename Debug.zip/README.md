# Game Development - Assignment 1

## Last Soldier

https://github.com/Gerard346/Game-Dev2019 -> Repository

https://github.com/Gerard346/Game-Dev2019/releases/tag/0.2 -> Release

W/A/S/D -> Controls for moving the player

SPACE -> Jump

F1-> Start From Level 1
F2-> Start From Level 2
F3-> Start From Level 3
F5-> Save
F6-> Load
F9-> View Colliders
F10-> God Mode
+-> More volume
--> Less volume

## Innovation

-Sliders 

-It blits only the tiles inside the area of the camera.

-Animations loading from xml

-Almost all the data such as player values, paths from files, animations, map values... all are load from either .xml or tiled.

-Player & sliders moves with dt.

-You can change the volume of the audio.

##Credits

https://bakudas.itch.io/generic-run-n-gun -> Sprites map & player


### Gerard Gil

MIT License

Copyright (c) 2019 Gerard346
