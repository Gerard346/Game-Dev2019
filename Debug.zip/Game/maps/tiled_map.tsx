<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="tiled_map" tilewidth="16" tileheight="16" tilecount="950" columns="38">
 <image source="../../../../vacaroxa--generic-run-n-gun-pack--v.1.0/tiles_map.png" width="608" height="400"/>
</tileset>
