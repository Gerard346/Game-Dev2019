<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="subway_BG" tilewidth="16" tileheight="16" tilecount="527" columns="31">
 <image source="../../../../vacaroxa--generic-run-n-gun-pack--v.1.0/Assets_area_1/Background/subway_BG.png" width="496" height="272"/>
</tileset>
